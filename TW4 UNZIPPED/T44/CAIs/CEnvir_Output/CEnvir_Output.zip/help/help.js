(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [
		{name:"help_atlas_", frames: [[1430,1588,37,15],[1469,1588,37,15],[1659,1533,23,21],[1666,1510,23,21],[1634,1551,23,21],[1641,1510,23,21],[1024,1412,23,21],[1024,1481,23,21],[1024,1435,23,21],[1024,1527,23,21],[1024,1458,23,21],[1024,1504,23,21],[1339,1563,33,19],[1304,1563,33,19],[1282,0,190,920],[1052,1412,691,96],[0,922,1022,636],[0,1756,1038,145],[1024,1118,1010,145],[1024,922,990,194],[1024,1265,968,145],[1040,1756,975,145],[0,1560,1050,194],[1052,1510,328,51],[1382,1510,131,37],[1382,1549,124,37],[1178,1563,124,37],[1508,1551,124,37],[1052,1563,124,37],[1515,1510,124,39],[1304,1588,124,37],[0,0,1280,920],[2016,0,8,842],[1745,1412,247,152]]}
];


// symbols:



(lib.button_exit_normal = function() {
	this.initialize(ss["help_atlas_"]);
	this.gotoAndStop(0);
}).prototype = p = new cjs.Sprite();



(lib.button_exit_over = function() {
	this.initialize(ss["help_atlas_"]);
	this.gotoAndStop(1);
}).prototype = p = new cjs.Sprite();



(lib.button_main_menu_normal = function() {
	this.initialize(ss["help_atlas_"]);
	this.gotoAndStop(2);
}).prototype = p = new cjs.Sprite();



(lib.button_main_menu_over = function() {
	this.initialize(ss["help_atlas_"]);
	this.gotoAndStop(3);
}).prototype = p = new cjs.Sprite();



(lib.button_nav_normal = function() {
	this.initialize(ss["help_atlas_"]);
	this.gotoAndStop(4);
}).prototype = p = new cjs.Sprite();



(lib.button_nav_over = function() {
	this.initialize(ss["help_atlas_"]);
	this.gotoAndStop(5);
}).prototype = p = new cjs.Sprite();



(lib.button_next_normal = function() {
	this.initialize(ss["help_atlas_"]);
	this.gotoAndStop(6);
}).prototype = p = new cjs.Sprite();



(lib.button_next_over = function() {
	this.initialize(ss["help_atlas_"]);
	this.gotoAndStop(7);
}).prototype = p = new cjs.Sprite();



(lib.button_prev_normal = function() {
	this.initialize(ss["help_atlas_"]);
	this.gotoAndStop(8);
}).prototype = p = new cjs.Sprite();



(lib.button_prev_over = function() {
	this.initialize(ss["help_atlas_"]);
	this.gotoAndStop(9);
}).prototype = p = new cjs.Sprite();



(lib.button_repeat_normal = function() {
	this.initialize(ss["help_atlas_"]);
	this.gotoAndStop(10);
}).prototype = p = new cjs.Sprite();



(lib.button_repeat_over = function() {
	this.initialize(ss["help_atlas_"]);
	this.gotoAndStop(11);
}).prototype = p = new cjs.Sprite();



(lib.button_resume_normal = function() {
	this.initialize(ss["help_atlas_"]);
	this.gotoAndStop(12);
}).prototype = p = new cjs.Sprite();



(lib.button_resume_over = function() {
	this.initialize(ss["help_atlas_"]);
	this.gotoAndStop(13);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_101 = function() {
	this.initialize(ss["help_atlas_"]);
	this.gotoAndStop(14);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_102 = function() {
	this.initialize(ss["help_atlas_"]);
	this.gotoAndStop(15);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_103 = function() {
	this.initialize(ss["help_atlas_"]);
	this.gotoAndStop(16);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_104 = function() {
	this.initialize(ss["help_atlas_"]);
	this.gotoAndStop(17);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_105 = function() {
	this.initialize(ss["help_atlas_"]);
	this.gotoAndStop(18);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_106 = function() {
	this.initialize(ss["help_atlas_"]);
	this.gotoAndStop(19);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_107 = function() {
	this.initialize(ss["help_atlas_"]);
	this.gotoAndStop(20);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_108 = function() {
	this.initialize(ss["help_atlas_"]);
	this.gotoAndStop(21);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_109 = function() {
	this.initialize(ss["help_atlas_"]);
	this.gotoAndStop(22);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_85 = function() {
	this.initialize(ss["help_atlas_"]);
	this.gotoAndStop(23);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_86 = function() {
	this.initialize(ss["help_atlas_"]);
	this.gotoAndStop(24);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_87 = function() {
	this.initialize(ss["help_atlas_"]);
	this.gotoAndStop(25);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_88 = function() {
	this.initialize(ss["help_atlas_"]);
	this.gotoAndStop(26);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_89 = function() {
	this.initialize(ss["help_atlas_"]);
	this.gotoAndStop(27);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_90 = function() {
	this.initialize(ss["help_atlas_"]);
	this.gotoAndStop(28);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_91 = function() {
	this.initialize(ss["help_atlas_"]);
	this.gotoAndStop(29);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_92 = function() {
	this.initialize(ss["help_atlas_"]);
	this.gotoAndStop(30);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_93 = function() {
	this.initialize(ss["help_atlas_"]);
	this.gotoAndStop(31);
}).prototype = p = new cjs.Sprite();



(lib.CachedTexturedBitmap_94 = function() {
	this.initialize(ss["help_atlas_"]);
	this.gotoAndStop(32);
}).prototype = p = new cjs.Sprite();



(lib._this = function() {
	this.initialize(ss["help_atlas_"]);
	this.gotoAndStop(33);
}).prototype = p = new cjs.Sprite();
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.reveal_mc = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// Layer_1
	this.instance = new lib.CachedTexturedBitmap_94();
	this.instance.parent = this;
	this.instance.setTransform(536,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

}).prototype = getMCSymbolPrototype(lib.reveal_mc, new cjs.Rectangle(536,0,4,421), null);


(lib.resume_btn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.button_resume_normal();
	this.instance.parent = this;

	this.instance_1 = new lib.button_resume_over();
	this.instance_1.parent = this;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).wait(3));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,33,19);


(lib.repeat_BTN = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.button_repeat_normal();
	this.instance.parent = this;

	this.instance_1 = new lib.button_repeat_over();
	this.instance_1.parent = this;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).wait(3));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,23,21);


(lib.nav_btn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 2
	this.instance = new lib.button_nav_normal();
	this.instance.parent = this;

	this.instance_1 = new lib.button_nav_over();
	this.instance_1.parent = this;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).wait(3));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,23,21);


(lib.menu_btn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.button_main_menu_normal();
	this.instance.parent = this;

	this.instance_1 = new lib.button_main_menu_over();
	this.instance_1.parent = this;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).wait(3));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,23,21);


(lib.fwd_btn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.button_next_normal();
	this.instance.parent = this;

	this.instance_1 = new lib.button_next_over();
	this.instance_1.parent = this;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).wait(3));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,23,21);


(lib.exit_btn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.button_exit_normal();
	this.instance.parent = this;

	this.instance_1 = new lib.button_exit_over();
	this.instance_1.parent = this;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).wait(3));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,37,15);


(lib.bck_btn = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer 1
	this.instance = new lib.button_prev_normal();
	this.instance.parent = this;

	this.instance_1 = new lib.button_prev_over();
	this.instance_1.parent = this;

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance}]}).to({state:[{t:this.instance_1}]},1).wait(3));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,0,23,21);


(lib.rollOverMSTR_mc = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}
	this.frame_2 = function() {
		this.stop();
	}
	this.frame_3 = function() {
		this.stop();
	}
	this.frame_4 = function() {
		this.stop();
	}
	this.frame_5 = function() {
		this.stop();
	}
	this.frame_6 = function() {
		this.stop();
	}
	this.frame_7 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1).call(this.frame_2).wait(1).call(this.frame_3).wait(1).call(this.frame_4).wait(1).call(this.frame_5).wait(1).call(this.frame_6).wait(1).call(this.frame_7).wait(1));

	// reveal_MC
	this.reveal_mc = new lib.reveal_mc();
	this.reveal_mc.name = "reveal_mc";
	this.reveal_mc.parent = this;
	this.reveal_mc.setTransform(199.75,126.95,1,1,0,0,0,270,210.5);

	this.timeline.addTween(cjs.Tween.get(this.reveal_mc).wait(8));

	// mask_idn (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_7 = new cjs.Graphics().p("AzTMYIAA4vMAmnAAAIAAYvg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:null,x:0,y:0}).wait(7).to({graphics:mask_graphics_7,x:164.675,y:109.25}).wait(1));

	// Layer_2
	this.instance = new lib._this();
	this.instance.parent = this;
	this.instance.setTransform(41,30);
	this.instance._off = true;

	var maskedShapeInstanceList = [this.instance];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(7).to({_off:false},0).wait(1));

	// rollOver_Text
	this.instance_1 = new lib.CachedTexturedBitmap_102();
	this.instance_1.parent = this;
	this.instance_1.setTransform(0,0,0.5,0.5);

	this.instance_2 = new lib.CachedTexturedBitmap_103();
	this.instance_2.parent = this;
	this.instance_2.setTransform(-59,-72.85,0.5,0.5);

	this.instance_3 = new lib.CachedTexturedBitmap_104();
	this.instance_3.parent = this;
	this.instance_3.setTransform(-59,-76.85,0.5,0.5);

	this.instance_4 = new lib.CachedTexturedBitmap_105();
	this.instance_4.parent = this;
	this.instance_4.setTransform(-59,-14.1,0.5,0.5);

	this.instance_5 = new lib.CachedTexturedBitmap_106();
	this.instance_5.parent = this;
	this.instance_5.setTransform(-59,43.9,0.5,0.5);

	this.instance_6 = new lib.CachedTexturedBitmap_107();
	this.instance_6.parent = this;
	this.instance_6.setTransform(-59,103.4,0.5,0.5);

	this.instance_7 = new lib.CachedTexturedBitmap_108();
	this.instance_7.parent = this;
	this.instance_7.setTransform(-59,168.15,0.5,0.5);

	this.instance_8 = new lib.CachedTexturedBitmap_109();
	this.instance_8.parent = this;
	this.instance_8.setTransform(-59,227.4,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_1}]}).to({state:[{t:this.instance_2}]},1).to({state:[{t:this.instance_3}]},1).to({state:[{t:this.instance_4}]},1).to({state:[{t:this.instance_5}]},1).to({state:[{t:this.instance_6}]},1).to({state:[{t:this.instance_7}]},1).to({state:[{t:this.instance_8}]},1).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-59,-83.5,528.8,421);


(lib.resume_btn_mc = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1));

	// button_states
	this.instance = new lib.resume_btn();
	this.instance.parent = this;
	this.instance.setTransform(40.75,21.35,1,1,0,0,0,16.5,9.5);
	new cjs.ButtonHelper(this.instance, 0, 1, 2, false, new lib.resume_btn(), 3);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(2));

	// trans_bck
	this.instance_1 = new lib.CachedTexturedBitmap_101();
	this.instance_1.parent = this;
	this.instance_1.setTransform(0,-323.4,0.5,0.5);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1).to({_off:false},0).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,-323.4,95,460);


(lib.repeat_btn_mc = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1));

	// btn_states
	this.instance = new lib.repeat_BTN();
	this.instance.parent = this;
	this.instance.setTransform(40.25,20.15,1,1,0,0,0,11.5,10.5);
	new cjs.ButtonHelper(this.instance, 0, 1, 2, false, new lib.repeat_BTN(), 3);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(2));

	// trans_bck
	this.instance_1 = new lib.CachedTexturedBitmap_101();
	this.instance_1.parent = this;
	this.instance_1.setTransform(0,-200.7,0.5,0.5);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1).to({_off:false},0).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,-200.7,95,460);


(lib.navigate_btn_mc = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1));

	// button_states
	this.instance = new lib.nav_btn();
	this.instance.parent = this;
	this.instance.setTransform(40.5,21.9,1,1,0,0,0,11.5,10.5);
	new cjs.ButtonHelper(this.instance, 0, 1, 2, false, new lib.nav_btn(), 3);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(2));

	// trans_bck
	this.instance_1 = new lib.CachedTexturedBitmap_101();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-0.05,-16.85,0.5,0.5);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1).to({_off:false},0).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,-16.8,95,460);


(lib.menu_btn_mc = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1));

	// button_states
	this.instance = new lib.menu_btn();
	this.instance.parent = this;
	this.instance.setTransform(40.35,22,1,1,0,0,0,11.5,10.5);
	new cjs.ButtonHelper(this.instance, 0, 1, 2, false, new lib.menu_btn(), 3);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(2));

	// trans_bck
	this.instance_1 = new lib.CachedTexturedBitmap_101();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-0.1,-78.1,0.5,0.5);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1).to({_off:false},0).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.1,-78.1,95,460);


(lib.forward_btn_mc = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1));

	// button_states
	this.instance = new lib.fwd_btn();
	this.instance.parent = this;
	this.instance.setTransform(40.05,18.7,1,1,0,0,0,11.5,10.5);
	new cjs.ButtonHelper(this.instance, 0, 1, 2, false, new lib.fwd_btn(), 3);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(2));

	// trans_bck
	this.instance_1 = new lib.CachedTexturedBitmap_101();
	this.instance_1.parent = this;
	this.instance_1.setTransform(0,-261.85,0.5,0.5);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1).to({_off:false},0).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,-261.8,95,460);


(lib.exit_btn_mc = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1));

	// button_states
	this.instance = new lib.exit_btn();
	this.instance.parent = this;
	this.instance.setTransform(40.2,21.4,1,1,0,0,0,18.5,7.5);
	new cjs.ButtonHelper(this.instance, 0, 1, 2, false, new lib.exit_btn(), 3);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(2));

	// trans_bck
	this.instance_1 = new lib.CachedTexturedBitmap_101();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-0.05,-384.55,0.5,0.5);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1).to({_off:false},0).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0,-384.5,95,460);


(lib.back_btn_mc = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		this.stop();
	}
	this.frame_1 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1).call(this.frame_1).wait(1));

	// button_states
	this.instance = new lib.bck_btn();
	this.instance.parent = this;
	this.instance.setTransform(40.05,23.45,1,1,0,0,0,11.5,10.5);
	new cjs.ButtonHelper(this.instance, 0, 1, 2, false, new lib.bck_btn(), 3);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(2));

	// trans_bck
	this.instance_1 = new lib.CachedTexturedBitmap_101();
	this.instance_1.parent = this;
	this.instance_1.setTransform(-0.25,-139.45,0.5,0.5);
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(1).to({_off:false},0).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(-0.2,-139.4,95,460);


// stage content:
(lib.help = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_0 = function() {
		// add listeners 
		setupListeners(exportRoot.navigate_mc);
		setupListeners(exportRoot.menu_mc);
		setupListeners(exportRoot.back_mc);
		setupListeners(exportRoot.repeat_mc);
		setupListeners(exportRoot.forward_mc);
		setupListeners(exportRoot.resume_mc);
		setupListeners(exportRoot.exit_mc);
		
		function setupListeners(mc){
			mc.addEventListener("mouseover", overEvent);
			mc.addEventListener("mouseout", outEvent);
		}
		//over event handler
		function overEvent(event){
			exportRoot.rollOver_MSTR_mc.reveal_mc.visible = false;
			event.target.gotoAndStop(2);
			console.log(event.currentTarget.name);
			switch (event.currentTarget) {
				case exportRoot.navigate_mc :
					exportRoot.rollOver_MSTR_mc.gotoAndStop(1);
					break;
				case exportRoot.menu_mc :
					exportRoot.rollOver_MSTR_mc.gotoAndStop(2);
					break;
				case exportRoot.back_mc :
					exportRoot.rollOver_MSTR_mc.gotoAndStop(3);
					break;
				case exportRoot.repeat_mc :
					exportRoot.rollOver_MSTR_mc.gotoAndStop(4);
					break;
				case exportRoot.forward_mc :
					exportRoot.rollOver_MSTR_mc.gotoAndStop(5);
					break;
				case exportRoot.resume_mc :
					exportRoot.rollOver_MSTR_mc.gotoAndStop(6);
					break;
				case exportRoot.exit_mc :
					exportRoot.rollOver_MSTR_mc.gotoAndStop(7);
					break;
			}
		}
		//out event handler
		function outEvent(event){
			event.currentTarget.gotoAndStop(1);
			exportRoot.rollOver_MSTR_mc.gotoAndStop(0);
			exportRoot.rollOver_MSTR_mc.reveal_mc.visible = true;
		}
		
		
		
		
		
		
		/* import flash.events.*;
		
		
		//
		// 17jan2014 ed: modifying the help file so that that the help contents just pop in
		// instead of transitioning in. still leaving the transition code here, just in case in
		// the future someone wants to put it back to how it was
		//
		
		
		
		var rollOver_MSTR_mc:MovieClip;
		
		var navigate_mc:MovieClip;
		var menu_mc:MovieClip;
		var back_mc:MovieClip;
		var repeat_mc:MovieClip;
		var forward_mc:MovieClip;
		var resume_mc:MovieClip;
		var exit_mc:MovieClip;
		
		
		//bckBtn_mc.addEventListener(MouseEvent.CLICK,bckOnClick);
		navigate_mc.addEventListener(MouseEvent.ROLL_OVER,textOver);
		navigate_mc.addEventListener(MouseEvent.ROLL_OUT,textOut);
		
		menu_mc.addEventListener(MouseEvent.ROLL_OVER,textOver);
		menu_mc.addEventListener(MouseEvent.ROLL_OUT,textOut);
		
		back_mc.addEventListener(MouseEvent.ROLL_OVER,textOver);
		back_mc.addEventListener(MouseEvent.ROLL_OUT,textOut);
		
		repeat_mc.addEventListener(MouseEvent.ROLL_OVER,textOver);
		repeat_mc.addEventListener(MouseEvent.ROLL_OUT,textOut);
		
		forward_mc.addEventListener(MouseEvent.ROLL_OVER,textOver);
		forward_mc.addEventListener(MouseEvent.ROLL_OUT,textOut);
		
		resume_mc.addEventListener(MouseEvent.ROLL_OVER,textOver);
		resume_mc.addEventListener(MouseEvent.ROLL_OUT,textOut);
		
		exit_mc.addEventListener(MouseEvent.ROLL_OVER,textOver);
		exit_mc.addEventListener(MouseEvent.ROLL_OUT,textOut);
		
		rollOver_MSTR_mc.reveal_mc.gotoAndStop(15);
		
		function textOver(event:MouseEvent):void {
		//	trace(event.target.name + "------OVER");
			if (event.target) {
				switch (event.target.name) {
					case "navigate_mc" :
						navigate_mc.gotoAndStop(2);
						//rollOver_MSTR_mc.reveal_mc.gotoAndPlay(2);
						rollOver_MSTR_mc.reveal_mc.visible = false;
						rollOver_MSTR_mc.gotoAndStop(2);
						break;
					case "menu_mc" :
						menu_mc.gotoAndStop(2);
						//rollOver_MSTR_mc.reveal_mc.gotoAndPlay(2);
						rollOver_MSTR_mc.reveal_mc.visible = false;
						rollOver_MSTR_mc.gotoAndStop(3);
						break;
					case "back_mc" :
						back_mc.gotoAndStop(2);
						//rollOver_MSTR_mc.reveal_mc.gotoAndPlay(2);
						rollOver_MSTR_mc.reveal_mc.visible = false;
						rollOver_MSTR_mc.gotoAndStop(4);
						break;
					case "repeat_mc" :
						repeat_mc.gotoAndStop(2);
						//rollOver_MSTR_mc.reveal_mc.gotoAndPlay(2);
						rollOver_MSTR_mc.reveal_mc.visible = false;
						rollOver_MSTR_mc.gotoAndStop(5);
						break;
					case "forward_mc" :
						forward_mc.gotoAndStop(2);
						//rollOver_MSTR_mc.reveal_mc.gotoAndPlay(2);
						rollOver_MSTR_mc.reveal_mc.visible = false;
						rollOver_MSTR_mc.gotoAndStop(6);
						break;
					case "resume_mc" :
						resume_mc.gotoAndStop(2);
						//rollOver_MSTR_mc.reveal_mc.gotoAndPlay(2);
						rollOver_MSTR_mc.reveal_mc.visible = false;
						rollOver_MSTR_mc.gotoAndStop(7);
						break;
					case "exit_mc" :
						exit_mc.gotoAndStop(2);
						//rollOver_MSTR_mc.reveal_mc.gotoAndPlay(2);
						rollOver_MSTR_mc.reveal_mc.visible = false;
						rollOver_MSTR_mc.gotoAndStop(8);
						break;
					}
			 }
		
		}
		
		function textOut(event:MouseEvent):void {
		//	trace(event.target.name + "------OUT");
			if (event.target) {
				switch (event.target.name) {
					case "navigate_mc" :
						navigate_mc.gotoAndStop(1);
						//rollOver_MSTR_mc.reveal_mc.gotoAndStop(15);
						rollOver_MSTR_mc.reveal_mc.visible = true;
						rollOver_MSTR_mc.gotoAndStop(1);
						break;
					case "menu_mc" :
						menu_mc.gotoAndStop(1);
						//rollOver_MSTR_mc.reveal_mc.gotoAndStop(15);
						rollOver_MSTR_mc.reveal_mc.visible = true;
						rollOver_MSTR_mc.gotoAndStop(1);
						break;
					case "back_mc" :
						back_mc.gotoAndStop(1);
						//rollOver_MSTR_mc.reveal_mc.gotoAndStop(15);
						rollOver_MSTR_mc.reveal_mc.visible = true;
						rollOver_MSTR_mc.gotoAndStop(1);
						break;
					case "repeat_mc" :
						repeat_mc.gotoAndStop(1);
						//rollOver_MSTR_mc.reveal_mc.gotoAndStop(15);
						rollOver_MSTR_mc.reveal_mc.visible = true;
						rollOver_MSTR_mc.gotoAndStop(1);
						break;
					case "forward_mc" :
						forward_mc.gotoAndStop(1);
						//rollOver_MSTR_mc.reveal_mc.gotoAndStop(15);
						rollOver_MSTR_mc.reveal_mc.visible = true;
						rollOver_MSTR_mc.gotoAndStop(1);
						break;
					case "resume_mc" :
						resume_mc.gotoAndStop(1);
						//rollOver_MSTR_mc.reveal_mc.gotoAndStop(15);
						rollOver_MSTR_mc.reveal_mc.visible = true;
						rollOver_MSTR_mc.gotoAndStop(1);
						break;
					case "exit_mc" :
						exit_mc.gotoAndStop(1);
						//rollOver_MSTR_mc.reveal_mc.gotoAndStop(15);
						rollOver_MSTR_mc.reveal_mc.visible = true;
						rollOver_MSTR_mc.gotoAndStop(1);
						break;
					}
			 }
			 
			 
		}
		
		
		*/
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).call(this.frame_0).wait(1));

	// TITLE
	this.instance = new lib.CachedTexturedBitmap_85();
	this.instance.parent = this;
	this.instance.setTransform(237.95,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(1));

	// Rollover_master
	this.rollOver_MSTR_mc = new lib.rollOverMSTR_mc();
	this.rollOver_MSTR_mc.name = "rollOver_MSTR_mc";
	this.rollOver_MSTR_mc.parent = this;
	this.rollOver_MSTR_mc.setTransform(331.05,134.65,1,1,0,0,0,172.8,24.1);

	this.timeline.addTween(cjs.Tween.get(this.rollOver_MSTR_mc).wait(1));

	// MC_buttons
	this.navigate_mc = new lib.navigate_btn_mc();
	this.navigate_mc.name = "navigate_mc";
	this.navigate_mc.parent = this;
	this.navigate_mc.setTransform(-79.95,46.85,1,1,0,0,0,41,29.2);

	this.menu_mc = new lib.menu_btn_mc();
	this.menu_mc.name = "menu_mc";
	this.menu_mc.parent = this;
	this.menu_mc.setTransform(41.1,68.3,1,1,0,0,0,41,29.2);

	this.back_mc = new lib.back_btn_mc();
	this.back_mc.name = "back_mc";
	this.back_mc.parent = this;
	this.back_mc.setTransform(41.2,129.6,1,1,0,0,0,41,29.2);

	this.repeat_mc = new lib.repeat_btn_mc();
	this.repeat_mc.name = "repeat_mc";
	this.repeat_mc.parent = this;
	this.repeat_mc.setTransform(40.95,190.85,1,1,0,0,0,41,29.2);

	this.forward_mc = new lib.forward_btn_mc();
	this.forward_mc.name = "forward_mc";
	this.forward_mc.parent = this;
	this.forward_mc.setTransform(40.95,252.05,1,1,0,0,0,41,29.2);

	this.exit_mc = new lib.exit_btn_mc();
	this.exit_mc.name = "exit_mc";
	this.exit_mc.parent = this;
	this.exit_mc.setTransform(41,374.75,1,1,0,0,0,41,29.2);

	this.resume_mc = new lib.resume_btn_mc();
	this.resume_mc.name = "resume_mc";
	this.resume_mc.parent = this;
	this.resume_mc.setTransform(40.95,313.6,1,1,0,0,0,41,29.2);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.resume_mc},{t:this.exit_mc},{t:this.forward_mc},{t:this.repeat_mc},{t:this.back_mc},{t:this.menu_mc},{t:this.navigate_mc}]}).wait(1));

	// button_Labels
	this.instance_1 = new lib.CachedTexturedBitmap_92();
	this.instance_1.parent = this;
	this.instance_1.setTransform(8.4,376.95,0.5,0.5);

	this.instance_2 = new lib.CachedTexturedBitmap_91();
	this.instance_2.parent = this;
	this.instance_2.setTransform(9.95,317.2,0.5,0.5);

	this.instance_3 = new lib.CachedTexturedBitmap_90();
	this.instance_3.parent = this;
	this.instance_3.setTransform(9.8,252,0.5,0.5);

	this.instance_4 = new lib.CachedTexturedBitmap_89();
	this.instance_4.parent = this;
	this.instance_4.setTransform(9.95,192.25,0.5,0.5);

	this.instance_5 = new lib.CachedTexturedBitmap_88();
	this.instance_5.parent = this;
	this.instance_5.setTransform(10.05,134.3,0.5,0.5);

	this.instance_6 = new lib.CachedTexturedBitmap_87();
	this.instance_6.parent = this;
	this.instance_6.setTransform(10.05,73.5,0.5,0.5);

	this.instance_7 = new lib.CachedTexturedBitmap_86();
	this.instance_7.parent = this;
	this.instance_7.setTransform(-111,50.05,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.instance_7},{t:this.instance_6},{t:this.instance_5},{t:this.instance_4},{t:this.instance_3},{t:this.instance_2},{t:this.instance_1}]}).wait(1));

	// bckgrnd
	this.instance_8 = new lib.CachedTexturedBitmap_93();
	this.instance_8.parent = this;
	this.instance_8.setTransform(0,0,0.5,0.5);

	this.timeline.addTween(cjs.Tween.get(this.instance_8).wait(1));

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(209,230,431,230);
// library properties:
lib.properties = {
	id: '7E575C3907A33F47A8343471E50AF996',
	width: 640,
	height: 460,
	fps: 30,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/help_atlas_.png?1589295670098", id:"help_atlas_"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['7E575C3907A33F47A8343471E50AF996'] = {
	getStage: function() { return exportRoot.getStage(); },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}			
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;			
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});			
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;			
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;