(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [];


(lib.AnMovieClip = function(){
	this.actionFrames = [];
	this.gotoAndPlay = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndPlay.call(this,positionOrLabel);
	}
	this.play = function(){
		cjs.MovieClip.prototype.play.call(this);
	}
	this.gotoAndStop = function(positionOrLabel){
		cjs.MovieClip.prototype.gotoAndStop.call(this,positionOrLabel);
	}
	this.stop = function(){
		cjs.MovieClip.prototype.stop.call(this);
	}
}).prototype = p = new cjs.MovieClip();
// symbols:



(lib.bitmap1 = function() {
	this.initialize(img.bitmap1);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,616,672);


(lib.bitmap10 = function() {
	this.initialize(img.bitmap10);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,615,672);


(lib.bitmap12 = function() {
	this.initialize(img.bitmap12);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,615,672);


(lib.bitmap3 = function() {
	this.initialize(img.bitmap3);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,615,672);


(lib.bitmap6 = function() {
	this.initialize(img.bitmap6);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,616,672);


(lib.bitmap8 = function() {
	this.initialize(img.bitmap8);
}).prototype = p = new cjs.Bitmap();
p.nominalBounds = new cjs.Rectangle(0,0,615,672);


(lib.Symbol13 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.bf(img.bitmap12, null, new cjs.Matrix2D(1,0,0,1,-307.4,-335.9)).s().p("EgwBA0fMAAAho9MBgEAAAMAAABo9g");
	this.shape.setTransform(307.5,336);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0.1,0.1,614.9,671.9);


(lib.Symbol11 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.bf(img.bitmap10, null, new cjs.Matrix2D(1,0,0,1,-307.4,-335.9)).s().p("EgwBA0fMAAAho9MBgEAAAMAAABo9g");
	this.shape.setTransform(307.5,336);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0.1,0.1,614.9,671.9);


(lib.Symbol9 = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.bf(img.bitmap8, null, new cjs.Matrix2D(1,0,0,1,-307.4,-335.9)).s().p("EgwBA0fMAAAho9MBgEAAAMAAABo9g");
	this.shape.setTransform(307.5,336);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(0.1,0.1,614.9,671.9);


// stage content:
(lib.Tgas5228b_HTML5Canvas = function(mode,startPosition,loop,reversed) {
if (loop == null) { loop = true; }
if (reversed == null) { reversed = false; }
	var props = new Object();
	props.mode = mode;
	props.startPosition = startPosition;
	props.labels = {};
	props.loop = loop;
	props.reversed = reversed;
	cjs.MovieClip.apply(this,[props]);

	this.actionFrames = [33];
	// timeline functions:
	this.frame_33 = function() {
		this.stop();
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(33).call(this.frame_33).wait(1));

	// Layer_2
	this.instance = new lib.Symbol9("synched",0);
	this.instance._off = true;

	this.instance_1 = new lib.Symbol11("synched",0);
	this.instance_1._off = true;

	this.instance_2 = new lib.Symbol13("synched",0);
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(4).to({_off:false},0).to({_off:true},1).wait(2).to({_off:false},0).to({_off:true},1).wait(2).to({_off:false},0).to({_off:true},1).wait(2).to({_off:false},0).to({_off:true},1).wait(2).to({_off:false},0).to({_off:true},1).wait(2).to({_off:false},0).to({_off:true},1).wait(2).to({_off:false},0).to({_off:true},1).wait(2).to({_off:false},0).to({_off:true},1).wait(2).to({_off:false},0).to({_off:true},1).wait(2).to({_off:false},0).to({_off:true},1).wait(2));
	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(5).to({_off:false},0).to({_off:true},1).wait(2).to({_off:false},0).to({_off:true},1).wait(2).to({_off:false},0).to({_off:true},1).wait(2).to({_off:false},0).to({_off:true},1).wait(2).to({_off:false},0).to({_off:true},1).wait(2).to({_off:false},0).to({_off:true},1).wait(2).to({_off:false},0).to({_off:true},1).wait(2).to({_off:false},0).to({_off:true},1).wait(2).to({_off:false},0).to({_off:true},1).wait(2).to({_off:false},0).to({_off:true},1).wait(1));
	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(6).to({_off:false},0).to({_off:true},1).wait(2).to({_off:false},0).to({_off:true},1).wait(2).to({_off:false},0).to({_off:true},1).wait(2).to({_off:false},0).to({_off:true},1).wait(2).to({_off:false},0).to({_off:true},1).wait(2).to({_off:false},0).to({_off:true},1).wait(2).to({_off:false},0).to({_off:true},1).wait(2).to({_off:false},0).to({_off:true},1).wait(2).to({_off:false},0).to({_off:true},1).wait(2).to({_off:false},0).wait(1));

	// Layer_3 (mask)
	var mask = new cjs.Shape();
	mask._off = true;
	var mask_graphics_0 = new cjs.Graphics().p("EgwBA0fMAAAho9MBgEAAAMAAABo9g");
	var mask_graphics_4 = new cjs.Graphics().p("EgdQAoKMAAAgxaMA6hAAAMAAAAxagEABSgm5IAAhQICMAAIAABQg");
	var mask_graphics_5 = new cjs.Graphics().p("EgdQAoKMAAAgxaMA6hAAAMAAAAxagEABSgmvIAAhaICMAAIAABag");
	var mask_graphics_6 = new cjs.Graphics().p("EgdQAoKMAAAgxaMA6hAAAMAAAAxagEABSgmmIAAhjICMAAIAABjg");
	var mask_graphics_7 = new cjs.Graphics().p("EgdQAoKMAAAgxaMA6hAAAMAAAAxagEABSgmdIAAhsICMAAIAABsg");
	var mask_graphics_8 = new cjs.Graphics().p("EgdQAoKMAAAgxaMA6hAAAMAAAAxagEABSgmUIAAh1ICMAAIAAB1g");
	var mask_graphics_9 = new cjs.Graphics().p("EgdQAoKMAAAgxaMA6hAAAMAAAAxagEABSgmKIAAh/ICMAAIAAB/g");
	var mask_graphics_10 = new cjs.Graphics().p("EgdQAoKMAAAgxaMA6hAAAMAAAAxagEABSgmBIAAiIICMAAIAACIg");
	var mask_graphics_11 = new cjs.Graphics().p("EgdQAoKMAAAgxaMA6hAAAMAAAAxagEABSgl3IAAiSICMAAIAACSg");
	var mask_graphics_12 = new cjs.Graphics().p("EgdQAoKMAAAgxaMA6hAAAMAAAAxagEABSgluIAAibICMAAIAACbg");
	var mask_graphics_13 = new cjs.Graphics().p("EgdQAoKMAAAgxaMA6hAAAMAAAAxagEABSgllIAAikICMAAIAACkg");
	var mask_graphics_14 = new cjs.Graphics().p("EgdQAoKMAAAgxaMA6hAAAMAAAAxagEABSglbIAAiuICMAAIAACug");
	var mask_graphics_15 = new cjs.Graphics().p("EgdQAoKMAAAgxaMA6hAAAMAAAAxagEABSglSIAAi3ICMAAIAAC3g");
	var mask_graphics_16 = new cjs.Graphics().p("EgdQAoKMAAAgxaMA6hAAAMAAAAxagEABSglIIAAjBICMAAIAADBg");
	var mask_graphics_17 = new cjs.Graphics().p("EgdQAoKMAAAgxaMA6hAAAMAAAAxagEABSgk/IAAjKICMAAIAADKg");
	var mask_graphics_18 = new cjs.Graphics().p("EgdQAoKMAAAgxaMA6hAAAMAAAAxagEABSgk1IAAjUICMAAIAADUg");
	var mask_graphics_19 = new cjs.Graphics().p("EgdQAoKMAAAgxaMA6hAAAMAAAAxagEABSgksIAAjdICMAAIAADdg");
	var mask_graphics_20 = new cjs.Graphics().p("EgdQAoKMAAAgxaMA6hAAAMAAAAxagEABSgkiIAAjnICMAAIAADng");
	var mask_graphics_21 = new cjs.Graphics().p("EgdQAoKMAAAgxaMA6hAAAMAAAAxagEABSgkZIAAjwICMAAIAADwg");
	var mask_graphics_22 = new cjs.Graphics().p("EgdQAoKMAAAgxaMA6hAAAMAAAAxagEABSgkPIAAj6ICMAAIAAD6g");
	var mask_graphics_23 = new cjs.Graphics().p("EgdQAoKMAAAgxaMA6hAAAMAAAAxagEABSgkGIAAkDICMAAIAAEDg");
	var mask_graphics_24 = new cjs.Graphics().p("EgdQAoKMAAAgxaMA6hAAAMAAAAxagEABSgj8IAAkNICMAAIAAENg");
	var mask_graphics_25 = new cjs.Graphics().p("EgdQAoKMAAAgxaMA6hAAAMAAAAxagEABSgjzIAAkWICMAAIAAEWg");
	var mask_graphics_26 = new cjs.Graphics().p("EgdQAoKMAAAgxaMA6hAAAMAAAAxagEABSgjqIAAkfICMAAIAAEfg");
	var mask_graphics_27 = new cjs.Graphics().p("EgdQAoKMAAAgxaMA6hAAAMAAAAxagEABSgjgIAAkpICMAAIAAEpg");
	var mask_graphics_28 = new cjs.Graphics().p("EgdQAoKMAAAgxaMA6hAAAMAAAAxagEABSgjXIAAkyICMAAIAAEyg");
	var mask_graphics_29 = new cjs.Graphics().p("EgdQAoKMAAAgxaMA6hAAAMAAAAxagEABSgjOIAAk7ICMAAIAAE7g");
	var mask_graphics_30 = new cjs.Graphics().p("EgdQAoKMAAAgxaMA6hAAAMAAAAxagEABSgjEIAAlFICMAAIAAFFg");
	var mask_graphics_31 = new cjs.Graphics().p("EgdQAoKMAAAgxaMA6hAAAMAAAAxagEABSgi7IAAlOICMAAIAAFOg");
	var mask_graphics_32 = new cjs.Graphics().p("EgdQAoKMAAAgxaMA6hAAAMAAAAxagEABSgiyIAAlXICMAAIAAFXg");
	var mask_graphics_33 = new cjs.Graphics().p("EgdQAoKMAAAgxaMA6hAAAMAAAAxagEABSgioIAAlhICMAAIAAFhg");

	this.timeline.addTween(cjs.Tween.get(mask).to({graphics:mask_graphics_0,x:307.5,y:336}).wait(4).to({graphics:mask_graphics_4,x:418.225,y:369.45}).wait(1).to({graphics:mask_graphics_5,x:418.225,y:369.45}).wait(1).to({graphics:mask_graphics_6,x:418.225,y:369.45}).wait(1).to({graphics:mask_graphics_7,x:418.225,y:369.45}).wait(1).to({graphics:mask_graphics_8,x:418.225,y:369.45}).wait(1).to({graphics:mask_graphics_9,x:418.225,y:369.45}).wait(1).to({graphics:mask_graphics_10,x:418.225,y:369.45}).wait(1).to({graphics:mask_graphics_11,x:418.225,y:369.45}).wait(1).to({graphics:mask_graphics_12,x:418.225,y:369.45}).wait(1).to({graphics:mask_graphics_13,x:418.225,y:369.45}).wait(1).to({graphics:mask_graphics_14,x:418.225,y:369.45}).wait(1).to({graphics:mask_graphics_15,x:418.225,y:369.45}).wait(1).to({graphics:mask_graphics_16,x:418.225,y:369.45}).wait(1).to({graphics:mask_graphics_17,x:418.225,y:369.45}).wait(1).to({graphics:mask_graphics_18,x:418.225,y:369.45}).wait(1).to({graphics:mask_graphics_19,x:418.225,y:369.45}).wait(1).to({graphics:mask_graphics_20,x:418.225,y:369.45}).wait(1).to({graphics:mask_graphics_21,x:418.225,y:369.45}).wait(1).to({graphics:mask_graphics_22,x:418.225,y:369.45}).wait(1).to({graphics:mask_graphics_23,x:418.225,y:369.45}).wait(1).to({graphics:mask_graphics_24,x:418.225,y:369.45}).wait(1).to({graphics:mask_graphics_25,x:418.225,y:369.45}).wait(1).to({graphics:mask_graphics_26,x:418.225,y:369.45}).wait(1).to({graphics:mask_graphics_27,x:418.225,y:369.45}).wait(1).to({graphics:mask_graphics_28,x:418.225,y:369.45}).wait(1).to({graphics:mask_graphics_29,x:418.225,y:369.45}).wait(1).to({graphics:mask_graphics_30,x:418.225,y:369.45}).wait(1).to({graphics:mask_graphics_31,x:418.225,y:369.45}).wait(1).to({graphics:mask_graphics_32,x:418.225,y:369.45}).wait(1).to({graphics:mask_graphics_33,x:418.225,y:369.45}).wait(1));

	// Layer_4
	this.shape = new cjs.Shape();
	this.shape.graphics.bf(img.bitmap6, null, new cjs.Matrix2D(1,0,0,1,-307.4,-335.9)).s().p("EgwBA0fMAAAho9MBgEAAAMAAABo9g");
	this.shape.setTransform(307.5,336);
	this.shape._off = true;

	var maskedShapeInstanceList = [this.shape];

	for(var shapedInstanceItr = 0; shapedInstanceItr < maskedShapeInstanceList.length; shapedInstanceItr++) {
		maskedShapeInstanceList[shapedInstanceItr].mask = mask;
	}

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(4).to({_off:false},0).wait(30));

	// Layer_5
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.bf(img.bitmap1, null, new cjs.Matrix2D(1,0,0,1,-307.4,-335.9)).s().p("EgwBA0fMAAAho9MBgEAAAMAAABo9g");
	this.shape_1.setTransform(307.5,336);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(34));

	this._renderFirstFrame();

}).prototype = p = new lib.AnMovieClip();
p.nominalBounds = new cjs.Rectangle(307.6,336.1,307.4,335.9);
// library properties:
lib.properties = {
	id: '50668799493FC34595FB5926B01A80D5',
	width: 615,
	height: 672,
	fps: 12,
	color: "#FFFFFF",
	opacity: 1.00,
	manifest: [
		{src:"images/bitmap1.jpg", id:"bitmap1"},
		{src:"images/bitmap10.png", id:"bitmap10"},
		{src:"images/bitmap12.png", id:"bitmap12"},
		{src:"images/bitmap3.png", id:"bitmap3"},
		{src:"images/bitmap6.jpg", id:"bitmap6"},
		{src:"images/bitmap8.png", id:"bitmap8"}
	],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.Stage();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['50668799493FC34595FB5926B01A80D5'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}
an.handleSoundStreamOnTick = function(event) {
	if(!event.paused){
		var stageChild = stage.getChildAt(0);
		if(!stageChild.paused){
			stageChild.syncStreamSounds();
		}
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;